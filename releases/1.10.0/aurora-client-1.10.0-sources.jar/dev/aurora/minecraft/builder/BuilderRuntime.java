package dev.aurora.minecraft.builder;

import dev.aurora.core.builder.*;
import dev.aurora.minecraft.AuroraClient;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.state.BlockState;

public final class BuilderRuntime implements BuildSession.Driver {
    private final AuroraClient client;
    public final BucketActions buckets=new BucketActions();
    private final BuildExitGuard exitGuard=new BuildExitGuard();
    private boolean escapeViewRequired;
    public final WaterSupply water;
    private BucketActions.Aim bucketAim;
    public final SchematicPreview preview=new SchematicPreview(this);
    private SchematicMaterials materials;
    private String materialsError="Choose a .litematic file first";
    public SchematicMaterials materials() {return materials;}
    public String materialsError() {return materialsError;}
    public boolean documentInWorld() {return document!=null && documentWorld==Minecraft.getInstance().level;}
    public int previewOpacity() {return client.config().number("auto_builder","preview_opacity",70);}
    public boolean previewVisible() {return documentInWorld() && client.config().flag("auto_builder","preview",true);}
    private void refreshSchematic() {
        preview.reset(document,anchor);
        try {materials=new SchematicMaterials(document,anchor);materials.tick(Minecraft.getInstance().level);materialsError="";}
        catch(RuntimeException error) {materials=null;materialsError=error.getMessage();}
    }
    private DirectSchematic document;
    private BlockPos anchor;
    private Object documentWorld;
    private NativePlacement.Attempt attempt;
    private BlockPos aimedTarget;
    private int aimTicks;
    private BuildPlan.Block activeBlock;
    private final Set<BlockPos> rejectedViews=new HashSet<>();
    public boolean requiresCrouch() {return attempt!=null && attempt.crouch() && !restock.busy() && !water.busy();}
    private int finalCheckTicks,clientTicks,lastPlacementTick=-4,placementClicks;
    private double maxPlacementDistance;
    public int placementClicks() {return placementClicks;}
    public double maxPlacementDistance() {return maxPlacementDistance;}
    public String schematicName() {return document==null?"Choose a .litematic file":document.name();}
    public DirectSchematic document() {return document;}
    public BlockPos anchor() {return anchor;}
    public void load(DirectSchematic selected) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null)throw new IllegalStateException("Join a world before selecting a schematic");
        stop("Schematic loaded");document=selected;anchor=mc.player.blockPosition().immutable();documentWorld=mc.level;session=null;
        client.config().setting("auto_builder","last_file",selected.file().toString());client.save();
        client.config().setting("auto_builder","preview","true");
        client.config().setting("auto_builder","materials_hud","true");
        client.save();
        refreshSchematic();message="Loaded "+selected.name();
    }
    public void cornerAtFeet() {
        if(document==null)throw new IllegalStateException("Choose a .litematic file first");
        Minecraft mc=Minecraft.getInstance();if(mc.player==null)throw new IllegalStateException("Join a world first");
        stop("Corner moved to feet");anchor=mc.player.blockPosition().immutable();documentWorld=mc.level;refreshSchematic();
    }
    public final WalkNavigator navigator=new WalkNavigator();
    public final RestockChests chests;
    public final RestockJob restock;
    private DirectSchematic.Snapshot snapshot;
    private BuildSession session;
    private boolean preflight;
    private Object level;
    private String message="Choose a .litematic file";
    private final Map<BlockPos,BlockState> confirmations=new HashMap<>();
    private final Set<BlockPos> awaiting=new HashSet<>();
    public void confirmed(BlockPos pos,BlockState state) {
        navigator.invalidate(pos);
        exitGuard.confirmed(pos);
        if(awaiting.contains(pos))confirmations.put(pos.immutable(),state);
        water.confirmed(pos,state);
        if(documentInWorld() && materials!=null)materials.changed(pos,Minecraft.getInstance().level);
    }
    public void inspectChests() { stop("Inspecting chests");level=Minecraft.getInstance().level;restock.startScan(); }
    private int moveTicks;
    public BuilderRuntime(AuroraClient client) { this.client=client;chests=new RestockChests(client);restock=new RestockJob(chests,navigator);water=new WaterSupply(client,navigator,buckets,chests::dimension); }
    public BuildSession.State state() { return session==null?BuildSession.State.IDLE:session.state(); }
    public String status() { return water.busy()?water.status():restock.busy()?restock.status():session==null?message:session.status(); }
    public boolean controlsInput() {
        return water.busy() || restock.busy() || session!=null && (session.state()==BuildSession.State.BUILDING || session.state()==BuildSession.State.RESTOCKING);
    }
    public void start() {
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null || mc.level==null)throw new IllegalStateException("Join a world first");
        boolean ownScreen=mc.gui.screen() instanceof dev.aurora.minecraft.AuroraScreen || mc.gui.screen() instanceof dev.aurora.minecraft.ModuleSettingsScreen;
        if(mc.gui.screen()!=null && !ownScreen)throw new IllegalStateException("Close other menus before starting the builder");
        if(document==null) {
            mc.gui.setScreen(new SchematicFileScreen(mc.gui.screen(),client,true));return;
        }
        if(documentWorld!=mc.level)throw new IllegalStateException("Move the schematic corner to your feet in this world first");
        var plan=document.at(anchor);
        for(var pos:plan.states().keySet())if(mc.level.isOutsideBuildHeight(pos))throw new IllegalStateException("Schematic extends outside the world build height");
        if(ownScreen)mc.gui.setScreen(null);
        startSnapshot(plan);
    }
    /** Also accepts an explicit immutable snapshot for the development integration runner. */
    public void startSnapshot(DirectSchematic.Snapshot plan) {
        stop("Preparing build");placementClicks=0;maxPlacementDistance=0;lastPlacementTick=clientTicks-4;snapshot=plan;level=Minecraft.getInstance().level;
        session=new BuildSession(plan.plan(),200);moveTicks=0;
        exitGuard.configure(plan,preferredExitPositions());
        var remaining=plan.plan().remaining(this::placed);
        water.configure(plan,remaining.stream().filter(b->b.item().equals("minecraft:water_bucket")).count());
        var missing=new HashMap<>(BuildPlan.missing(BuildPlan.materials(remaining),inventory()));
        if(water.canSupply())missing.remove("minecraft:water_bucket");
        if(missing.isEmpty())session.start(this);
        else { restock.startScan();preflight=true; }
    }
    public void stop(String reason) {
        preflight=false;navigator.stop();restock.cancel(reason);water.cancel();buckets.cancel();bucketAim=null;awaiting.clear();confirmations.clear();finalCheckTicks=0;activeBlock=null;escapeViewRequired=false;rejectedViews.clear();attempt=null;aimedTarget=null;
        if(session!=null)session.pause(reason);message=reason;
    }
    public void tick() {
        clientTicks++;
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null || mc.level==null)return;
        chests.outlines();water.outlines();
        if(documentInWorld() && materials!=null)materials.tick(mc.level);
        if(controlsInput() && (mc.level!=level || !mc.player.isAlive())) { stop("World changed or player died; restart explicitly");return; }
        if(water.busy())water.tick();
        if(controlsInput() && !water.failure().isEmpty()) {stop(water.failure());return;}
        if(restock.busy())restock.tick();
        if(preflight && !restock.busy()) {
            preflight=false;
            if(restock.failed() || !restock.stock().inspected()) { stop(restock.status());return; }
            session.start(this);
        }
        if(session!=null && !preflight && (mc.gui.screen()==null || restock.busy())) {
            try { session.tick(this); }
            catch(RuntimeException error) { stop(error.getMessage()==null?"Builder failed":error.getMessage()); }
            if(session.state()==BuildSession.State.COMPLETE || session.state()==BuildSession.State.PAUSED || session.state()==BuildSession.State.MISSING_MATERIALS)navigator.stop();
        }
    }
    public boolean actionKey(int key) {
        // Preserve explicit module bindings from earlier Aurora versions over new default action keys.
        for(var module:client.modules().all())if(key!=0 && client.config().number(module.id(),"key",0)==key)return false;
        int anchor=client.config().number("auto_builder","anchor_key",10);
        int bind=client.config().number("auto_builder","restock_key",25);
        if(key==0 || key!=anchor && key!=bind)return false;
        try {
            if(key==anchor) { stop("Placement moved");cornerAtFeet();message="Schematic corner moved to your feet"; }
            else { stop("Restock selection changed");chests.bindLookedAt();restock.invalidate();message="Restock chest selection updated"; }
            Minecraft.getInstance().gui.hud.getChat().addClientSystemMessage(Component.literal("Aurora: "+message));
        }catch(RuntimeException error) { message=error.getMessage();Minecraft.getInstance().gui.hud.getChat().addClientSystemMessage(Component.literal("Aurora: "+message)); }
        return true;
    }
    @Override public String worldIdentity() { return Integer.toHexString(System.identityHashCode(Minecraft.getInstance().level)); }
    @Override public boolean placed(BuildPlan.Block block) {
        Minecraft mc=Minecraft.getInstance();BlockPos pos=new BlockPos(block.x(),block.y(),block.z());
        var recipe=snapshot.recipes().get(pos);
        BlockState actual=awaiting.contains(pos)?confirmations.get(pos):mc.level.getBlockState(pos);
        if(actual==null || recipe==null || !mc.level.hasChunkAt(pos) || !recipe.done(block.stage(),actual))return false;
        return snapshot.companions().getOrDefault(pos,List.of()).stream().allMatch(p->PlacementRecipes.equivalent(awaiting.contains(p)?confirmations.get(p):mc.level.getBlockState(p),snapshot.states().get(p)));
    }
    @Override public String confirmationFailure(BuildPlan.Block block) {
        var pos=new BlockPos(block.x(),block.y(),block.z());
        var confirmed=confirmations.get(pos);
        String observed=confirmed==null?"no server block update":confirmed.toString();
        AuroraClient.LOG.warn("Placement confirmation failed: target={} expected={} observed={}",pos,block.state(),observed);
        return "Unconfirmed block at "+pos.toShortString()+"; expected "+block.state()+"; server: "+observed;
    }
    @Override public boolean completionReady() {
        var mc=Minecraft.getInstance();
        long unmatched=snapshot.states().entrySet().stream().filter(e->mc.level.getBlockState(e.getKey())!=e.getValue()).count();
        if(unmatched==0)return true;
        if(++finalCheckTicks>=40)throw new IllegalStateException("Automatic steps finished; "+unmatched+" blocks still need manual state/growth or support. See the preview.");
        return false;
    }
    @Override public Map<String,Integer> inventory() { return RestockJob.inventory(); }
    @Override public BuildSession.Stock stock() {
        var stock=restock.stock();if(!water.canSupply())return stock;
        var items=new HashMap<>(stock.items());items.merge("minecraft:water_bucket",2,Math::max);
        var own=new HashMap<>(inventory());own.merge("minecraft:water_bucket",2,Math::max);
        boolean enough=snapshot!=null && BuildPlan.missing(BuildPlan.materials(snapshot.plan().remaining(this::placed)),own).isEmpty();
        return new BuildSession.Stock(items,stock.inspected() || enough);
    }
    @Override public double placementPriority(BuildPlan.Block block) {
        var mc=Minecraft.getInstance();var pos=new BlockPos(block.x(),block.y(),block.z());
        double distance=mc.player.getEyePosition().distanceToSqr(net.minecraft.world.phys.Vec3.atCenterOf(pos));
        // A target intersecting our own body needs a move; finish nearby unobstructed targets first.
        var step=snapshot.recipes().get(pos).steps().get(block.stage());
        if(step.kind()==PlacementRecipes.Kind.PLACE)for(var box:step.state().getCollisionShape(mc.level,pos).toAabbs())
            if(box.move(pos).intersects(mc.player.getBoundingBox()))return distance+1000;
        return distance;
    }
    @Override public boolean busyRestocking() {return restock.busy() || water.busy();}
    @Override public String placementBlocker(BuildPlan.Block block) {
        var mc=Minecraft.getInstance();var pos=new BlockPos(block.x(),block.y(),block.z());var recipe=snapshot.recipes().get(pos);
        if(block.stage()>0 && !recipe.done(block.stage()-1,mc.level.getBlockState(pos)))return "Finish the earlier recipe step at "+pos.toShortString();
        var step=recipe.steps().get(block.stage());
        if(step.kind()==PlacementRecipes.Kind.PLACE && !step.state().canSurvive(mc.level,pos))return "Missing support for "+block.item()+" at "+pos.toShortString();
        return "";
    }
    @Override public BuildSession.Restock restockFor(BuildPlan.Block next,Map<String,Integer> requirements) {
        if(next.item().equals("minecraft:water_bucket") && (water.ready() || water.canSupply())) {
            if(water.busy())return BuildSession.Restock.PENDING;
            if(!water.ready()) {water.prepare();return BuildSession.Restock.PENDING;}
            if(inventory().getOrDefault("minecraft:water_bucket",0)>0)return BuildSession.Restock.COMPLETE;
            water.refill();return BuildSession.Restock.PENDING;
        }
        var wanted=new HashMap<>(requirements);if(water.canSupply())wanted.remove("minecraft:water_bucket");
        if(restock.busy())return BuildSession.Restock.PENDING;
        if(restock.failed())throw new IllegalStateException(restock.status());
        if(inventory().getOrDefault(next.item(),0)>=next.count())return BuildSession.Restock.COMPLETE;
        try {attempt=null;aimedTarget=null;navigator.stop();restock.startRestock(wanted,next.item(),next.count());return BuildSession.Restock.PENDING;}
        catch(RuntimeException error){message=error.getMessage();return BuildSession.Restock.BLOCKED;}
    }
    @Override public BuildSession.Restock restock(Map<String,Integer> requirements) {
        if(restock.busy())return BuildSession.Restock.PENDING;
        if(restock.failed())throw new IllegalStateException(restock.status());
        if(restock.status().equals("Restock complete") && BuildPlan.missing(requirements,inventory()).isEmpty())return BuildSession.Restock.COMPLETE;
        try { restock.startRestock(requirements);return BuildSession.Restock.PENDING; }
        catch(RuntimeException error) { message=error.getMessage();return BuildSession.Restock.BLOCKED; }
    }
    @Override public boolean preparePlacement(BuildPlan.Block block) {
        Minecraft mc=Minecraft.getInstance();
        if(restock.busy() || water.busy() || mc.gui.screen()!=null)return false;
        if(block.item().equals("minecraft:water_bucket")) {
            int seeds=water.seedBucketsNeeded();
            if(inventory().getOrDefault("minecraft:water_bucket",0)<seeds) {
                if(restock.failed())throw new IllegalStateException(restock.status());
                restock.startRestock(Map.of("minecraft:water_bucket",seeds));return false;
            }
            if(!water.prepare())return false;
        }
        if(!block.equals(activeBlock)) {
            activeBlock=block;escapeViewRequired=false;rejectedViews.clear();moveTicks=0;navigator.stop();attempt=null;bucketAim=null;aimedTarget=null;
        }
        if(clientTicks-lastPlacementTick<4)return false;
        if(++moveTicks>1200)throw new IllegalStateException("Could not reach the next block within 60 seconds");
        BlockPos target=new BlockPos(block.x(),block.y(),block.z());
        if(!mc.level.hasChunkAt(target))throw new IllegalStateException("Target chunk is not loaded");
        var actual=mc.level.getBlockState(target);var recipe=snapshot.recipes().get(target);var step=recipe.steps().get(block.stage());var expected=step.state();
        if(SchematicFluids.source(expected) && !actual.getFluidState().isEmpty() && actual.getBlock()!=expected.getBlock())
            throw new IllegalStateException("Remove the conflicting fluid at "+target.toShortString());
        if(!actual.canBeReplaced() && !placed(block) && !recipe.canContinue(block.stage(),actual))throw new IllegalStateException("Remove the conflicting block at "+target.toShortString());
        if(!buckets.select(block.item()))return false;
        try {
            if(!navigator.walkToPlacement(target,feet->!rejectedViews.contains(BlockPos.containing(feet)) && !BlockPos.containing(feet).equals(target) && NativePlacement.visibleFrom(target,step,feet) && (!escapeViewRequired || exitGuard.canPlaceFrom(target,expected,feet))))return false;
        }catch(IllegalStateException error) {throw placementFailure(block,target,error);}
        if(!mc.player.onGround() || mc.player.getDeltaMovement().horizontalDistanceSqr()>0.0025)return false;
        try {
        if(step.kind()==PlacementRecipes.Kind.BUCKET) {
            if(!target.equals(aimedTarget) || bucketAim==null) {bucketAim=BucketActions.find(target,false,expected.hasProperty(net.minecraft.world.level.block.state.properties.BlockStateProperties.WATERLOGGED));aimedTarget=target;aimTicks=2;}
            bucketAim.aim();if(aimTicks-->0)return false;
            bucketAim=BucketActions.find(target,false,expected.hasProperty(net.minecraft.world.level.block.state.properties.BlockStateProperties.WATERLOGGED));
        }else {
            if(!target.equals(aimedTarget) || attempt==null) {attempt=findAttempt(target,step);attempt.aim();attempt.sendRotation();aimedTarget=target;aimTicks=aimDelay(attempt,step);}
            attempt.aim();if(aimTicks-->0)return false;
            if(!attempt.visible()) {attempt=findAttempt(target,step);attempt.aim();attempt.sendRotation();aimTicks=aimDelay(attempt,step);return false;}
        }
        }catch(IllegalStateException error) {
            rejectedViews.add(mc.player.blockPosition().immutable());
            if(rejectedViews.size()>=12)throw placementFailure(block,target,error);
            navigator.stop();attempt=null;bucketAim=null;aimedTarget=null;return false;
        }
        // Preserve a route to the verified exterior/restock anchor. If a last wall would
        // close the passage, select an exterior stance and place it from that side instead.
        if(step.kind()==PlacementRecipes.Kind.PLACE && !exitGuard.canPlace(target,expected)) {
            escapeViewRequired=true;
            rejectedViews.add(mc.player.blockPosition().immutable());
            navigator.stop();attempt=null;bucketAim=null;aimedTarget=null;
            if(rejectedViews.size()>=12)throw new IllegalStateException(exitGuard.reason());
            return false;
        }
        moveTicks=0;return true;
    }
    private List<BlockPos> preferredExitPositions() {
        var positions=new ArrayList<BlockPos>();
        for(var chest:chests.current())for(var direction:net.minecraft.core.Direction.Plane.HORIZONTAL)
            for(int dy=-1;dy<=1;dy++)positions.add(chest.pos().relative(direction).offset(0,dy,0));
        return positions;
    }
    private int aimDelay(NativePlacement.Attempt candidate,PlacementRecipes.Step step) {
        // Piston/observer direction uses server-side head yaw, updated by Player.aiStep
        // after movement packets. Hold the requested look across complete server ticks.
        boolean oriented=step.state().getProperties().stream()
            .anyMatch(p->p.getName().equals("facing") || p.getName().equals("rotation"));
        if(oriented)return 3;
        if(candidate.crouch())return 2;
        return candidate.air()?1:0;
    }
    private NativePlacement.Attempt findAttempt(BlockPos target,PlacementRecipes.Step step) {
        return step.kind()==PlacementRecipes.Kind.INTERACT?NativePlacement.interact(target):step.kind()==PlacementRecipes.Kind.AIR_USE?NativePlacement.airUse(target,step):NativePlacement.find(target,step);
    }
    private IllegalStateException placementFailure(BuildPlan.Block block,BlockPos target,RuntimeException cause) {
        AuroraClient.LOG.warn("Placement blocked: desired={} at {}: {}",block.state(),target,cause.getMessage());
        return new IllegalStateException(block.item()+" at "+target.toShortString()+" needs a clear path/support or a state change (see preview)");
    }
    @Override public void place(BuildPlan.Block block) {
        Minecraft mc=Minecraft.getInstance();BlockPos target=new BlockPos(block.x(),block.y(),block.z());
        awaiting.add(target.immutable());confirmations.remove(target);
        for(BlockPos companion:snapshot.companions().getOrDefault(target,List.of())) {awaiting.add(companion);confirmations.remove(companion);}
        if(snapshot.recipes().get(target).steps().get(block.stage()).kind()==PlacementRecipes.Kind.BUCKET) {
            if(bucketAim==null)throw new IllegalStateException("No validated bucket ray");bucketAim.use();bucketAim=null;
        }else {
            if(attempt==null)throw new IllegalStateException("No validated placement context");
            double distance=mc.player.getEyePosition().distanceTo(attempt.hit().getLocation());
            attempt.click();maxPlacementDistance=Math.max(maxPlacementDistance,distance);attempt=null;
        }
        placementClicks++;lastPlacementTick=clientTicks;
        aimedTarget=null;activeBlock=null;rejectedViews.clear();
    }
    public void drawStatus(GuiGraphicsExtractor graphics) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null || mc.gui.hud.isHidden() || !controlsInput() && !client.enabled("auto_builder") && (document==null || !client.config().flag("auto_builder","preview",true)))return;
        String text=mc.font.plainSubstrByWidth("Auto Builder: "+(controlsInput() || client.enabled("auto_builder") ? status() : "Preview: "+schematicName()),Math.max(40,graphics.guiWidth()-24));
        graphics.text(mc.font,text,Math.max(6,(graphics.guiWidth()-mc.font.width(text))/2),6,0xffc4baff,true);
    }
}
