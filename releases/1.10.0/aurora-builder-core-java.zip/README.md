# Auto Schematic Builder – ren Java-kärna

Java 25. Kärnan kräver varken Minecraft, Fabric eller Forge.
Den simulerade adaptern i exemplet skriver ut ett klick och visar väntan på
serverbekräftelse. Den ändrar ingen Minecraft-värld.

Kompilera från den uppackade mappen:

javac -d out src/main/java/dev/aurora/core/builder/AStarPathfinder.java src/main/java/dev/aurora/core/builder/BuildPlan.java src/main/java/dev/aurora/core/builder/BuildSession.java examples/AlgorithmExample.java
java -cp out AlgorithmExample

För faktisk blockplacering behövs spelets adapter. Den dokumenterade
Fabric-implementationen, terrängkontroll, rörelse, rotation och utvägskontroll finns i:
https://github.com/powerebraceit/Minecraft-Client/tree/v1.10.0/src/main/java/dev/aurora/minecraft/builder

Fullständig genomgång:
https://github.com/powerebraceit/Minecraft-Client/blob/v1.10.0/docs/BUILDER_ALGORITHM.md

Forge kräver en egen speladapter. En färdig Forge-mod ingår inte.
